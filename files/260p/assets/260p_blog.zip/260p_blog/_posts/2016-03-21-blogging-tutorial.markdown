---
layout: post
title:  "Blogging Tutorial"
date:   2016-03-21 10:24:31
categories: lectures
mathjax: true
---

Each of you will have a local version of the blog on your own machine that you can use to produce and test your posts on. You can download your local version of the site directory [here]()

You’ll find this post in your `_posts` directory. Go ahead and edit it and re-build the site to see your changes. You can rebuild the site in many different ways, but the most common way is to run `jekyll serve`, which launches a web server and auto-regenerates your site when a file is updated. 

To add new posts, simply add a file in the `_posts` directory that follows the convention `YYYY-MM-DD-name-of-post.ext` (this post is called `2016-03-21-blogging-tutorial.markdown`) and includes the necessary front matter (i.e. the stuff at the top enclosed by the triple dashes). It is also important that the date in the front matter match the date in the filename. In general I would suggest using this post as a template and only changing the `title` and `date` variables when you create a new post. 

In order to write our posts we will be using a syntax known as Markdown. It is very simple to work with and gives you the ability to produce very nice results with very little code. Take a look at the source for this post to get a rough idea about how it works. A more detailed and useful Markdown tutorial can be found [here][markdown].

Jekyll/markdown also supports $$\TeX$$ integration via MathJax in a very simple way. If you want to add Tex to your post, just surround the standard Tex code with double dollar signs. For example `$$\sum_{i=1}^ni=(n+1)n/2$$` will complile as $$\sum_{i=1}^ni=(n+1)n/2$$. 

I'm not sure that you will need it, but Jekyll also offers powerful support for code snippets: 

{% highlight ruby %}
def print_hi(name)
  puts "Hi, #{name}"
end
print_hi('Tom')
#=> prints 'Hi, Tom' to STDOUT.
{% endhighlight %}

Check out the [Jekyll docs][jekyll] for more info on how to get the most out of Jekyll. 






[markdown]:    https://guides.github.com/features/mastering-markdown
[jekyll]:      http://jekyllrb.com
[jekyll-gh]:   https://github.com/jekyll/jekyll
[jekyll-help]: https://github.com/jekyll/jekyll-help  