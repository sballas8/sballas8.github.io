---
layout: page
title: About
permalink: /about/
---

This blog contains the lecture notes for the course Math 260P taught in Spring 2016 at UC Santa Barbara by Sam Ballas and Daryl Cooper. 


